import subprocess
import sys

# pip'in yüklü olup olmadığını kontrol et
def check_and_install_pip():
    try:
        # pip versiyonunu kontrol et
        subprocess.check_call([sys.executable, '-m', 'pip', '--version'])
    except subprocess.CalledProcessError:
        print("pip yüklü değil, yükleniyor...")
        # pip'i yükle
        subprocess.check_call([sys.executable, '-m', 'ensurepip', '--upgrade'])

# pip'i kontrol et ve yükle
check_and_install_pip()

# Kütüphanelerin listesi
required_libraries = [
    'flask',
    'flask_socketio',
    'os',
    'random',
    'json',
    'hashlib',
    'shutil'
]

# Eksik kütüphaneleri kontrol et ve yükle
for library in required_libraries:
    try:
        # Kütüphaneyi import etmeye çalış
        __import__(library)
    except ImportError:
        print(f"'{library}' kütüphanesi eksik. Yükleniyor...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", library])


from flask import Flask, render_template, request, redirect, url_for, session
from flask_socketio import SocketIO, send, join_room, leave_room
import os
import random
import json
import hashlib
import shutil

# Flask ve SocketIO uygulamaları
app = Flask(__name__)
socketio = SocketIO(app)
app.secret_key = 'secret!'
app.config['SESSION_TYPE'] = 'filesystem'

# Kullanıcı verilerini saklamak için JSON dosyası
USERS_FILE = 'users.json'

# Kullanıcı renklerini saklamak için bir sözlük
user_colors = {}

# Odaların mesajlarını saklamak için bir dosya yönetimi
ROOMS_DIR = 'odalar'

# Kullanıcıları yüklemek
def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return {}

# Kullanıcıları kaydetmek
def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f)

# Kullanıcı adı ve şifre doğrulama
def verify_user(username, password):
    users = load_users()
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    return users.get(username) == hashed_password

# Kullanıcıyı kaydetme
def register_user(username, password):
    users = load_users()
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    users[username] = hashed_password
    save_users(users)

# Odaların mesajlarını yükleme
def load_room_messages(room_name):
    room_path = os.path.join(ROOMS_DIR, room_name, 'messages.txt')
    if os.path.exists(room_path):
        with open(room_path, 'r') as f:
            return f.readlines()
    return []

# Odaların listesi
def load_rooms():
    if not os.path.exists(ROOMS_DIR):
        os.mkdir(ROOMS_DIR)
    return [folder for folder in os.listdir(ROOMS_DIR) if os.path.isdir(os.path.join(ROOMS_DIR, folder))]

# Mesajları kaydetme
def save_room_message(room_name, message):
    room_path = os.path.join(ROOMS_DIR, room_name)
    if not os.path.exists(room_path):
        os.mkdir(room_path)
    with open(os.path.join(room_path, 'messages.txt'), 'a') as f:
        f.write(message + "\n")

# Kullanıcı oturumunu başlatma
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if verify_user(username, password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Kullanıcı adı veya şifre hatalı.")
    return render_template('login.html')

# Kullanıcı kaydını oluşturma
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username and password:
            users = load_users()  # Sunucudaki mevcut kullanıcıları yükle
            
            # Kullanıcı adını kontrol et
            if username in users:
                return render_template('register.html', error="Bu kullanıcı adı kullanılıyor.")
            
            # Kullanıcıyı kaydet
            register_user(username, password)
            return redirect(url_for('login'))
    
    return render_template('register.html')


# Anasayfa (sohbet odaları ve giriş)
@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))  # Kullanıcı girmediyse login sayfasına yönlendir
    rooms = load_rooms()
    return render_template('index.html', rooms=rooms)

@app.route('/create_room', methods=['POST'])
def create_room():
    room_name = request.form['room_name']
    if room_name not in load_rooms():
        os.mkdir(os.path.join(ROOMS_DIR, room_name))
        socketio.emit('redirect_to_index')
    return redirect(url_for('index'))

@socketio.on('join')
def join(room_name):
    username = session.get('username', 'Anonim')
    join_room(room_name)

    # Odaya katıldığını bildiren mesaj
    join_message = "//!clearallchat"
    send(join_message, room=room_name)
    
    # Oda mesajlarını al
    messages = load_room_messages(room_name)
    for message in messages:
        send(message, room=room_name)
    
@socketio.on('delete_room')
def delete_room(room_name):
    # Odaya ait dizinin yolu
    room_path = os.path.join(ROOMS_DIR, room_name)

    # Eğer oda mevcutsa
    if os.path.exists(room_path):
        # Dizin içeriğini temizle (dosya ve alt dizinleri sil)
        shutil.rmtree(room_path)  # Dizin içeriğini ve dizini tamamen sil

        # Odayı sildikten sonra tüm bağlı kullanıcılara yönlendirme mesajı gönder
        socketio.emit('redirect_to_index')  # Sayfayı tüm kullanıcılara yönlendir

        # Odayı sildikten sonra odaya bağlı olan tüm kullanıcılara bu mesajı gönder
        send("Oda silindi. Sayfa yenileniyor...", room=room_name)


@socketio.on('message')
def handle_message(msg, room_name):
    colors = [
    '#FFEB3B',  # Sarı
    '#8BC34A',  # Açık yeşil
    '#00BCD4',  # Açık mavi
    '#FF9800',  # Açık turuncu
    '#03A9F4',  # Mavi
    '#4CAF50',  # Yeşil
    '#FF5722',  # Mercan rengi
    '#9C27B0',  # Mor
    '#607D8B',  # Gri mavi
    '#CDDC39',  # Lime
    '#FFC107',  # Amber
    '#FFEB3B',  # Sarı
    '#2196F3',  # Mavi
    '#00E5FF',  # Açık mavi
    '#009688',  # Camgöbeği
    '#9E9D24',  # Zeytin yeşili
    '#FF4081',  # Pembe
    '#673AB7',  # Mor
    '#FF9800',  # Turuncu
    '#8E24AA'   # Mor tonları
    ]
    username = session.get('username', 'Anonim')
    
    # Kullanıcıya renk atama
    if username not in user_colors:
        user_colors[username] = random.choice(colors)
    
    color = user_colors[username]
    formatted_msg = f'<span style="color:{color}; font-weight:bold;">{username}</span>: {msg}'
    
    # Eğer mesaj '//!deletechat' içeriyorsa, oda silinecek
    if msg.strip() == '//!deletechat':
        delete_room(room_name)
        return
    
    # Mesajı odaya kaydet
    save_room_message(room_name, formatted_msg)
    
    # Mesajı odada olanlara gönder
    send(formatted_msg, room=room_name)

@socketio.on('leave')
def leave(room_name):
    leave_room(room_name)

if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
